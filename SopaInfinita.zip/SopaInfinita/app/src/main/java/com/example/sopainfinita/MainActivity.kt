package com.example.sopainfinita

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sign
import kotlin.random.Random

val PALABRAS = ("GATO PERRO CASA ARBOL LIBRO MESA SILLA NUBE LUNA ESTRELLA MAR RIO MONTE BOSQUE PLAYA ISLA DESIERTO VOLCAN " +
    "NIEVE LLUVIA VIENTO TRUENO SOL PLANETA COHETE ROBOT CAMINO PUENTE CIUDAD PUEBLO ESCUELA CLASE LAPIZ CUADERNO PAPEL " +
    "TIGRE LEON OSO LOBO ZORRO CONEJO RATON PATO CABALLO VACA OVEJA CERDO GALLO PAJARO PEZ DELFIN BALLENA TORTUGA " +
    "MANZANA PERA UVA LIMON NARANJA FRESA SANDIA MELON BANANA COCO PAN QUESO LECHE SOPA PIZZA TACO ARROZ FRIJOL MAIZ " +
    "AZUL ROJO VERDE AMARILLO NEGRO BLANCO ROSADO MORADO GRIS CAFE MUSICA GUITARRA PIANO TAMBOR FLAUTA BAILE CANCION " +
    "FUTBOL TENIS NATACION CARRERA JUEGO PREMIO EQUIPO AMIGO FAMILIA ABUELO HERMANO PRIMO VECINO MAESTRO DOCTOR PINTOR").split(" ")

class Puzzle(val n: Int, val grid: Array<CharArray>, val words: List<String>, val inicio: Map<String, Pair<Int, Int>>)

fun generar(n: Int, cuantas: Int): Puzzle {
    val g = Array(n) { CharArray(n) { ' ' } }
    val dirs = listOf(0 to 1, 1 to 0, 1 to 1, -1 to 1, 0 to -1, -1 to 0, -1 to -1, 1 to -1)
    val puestas = mutableListOf<String>(); val ini = mutableMapOf<String, Pair<Int, Int>>()
    for (w in PALABRAS.filter { it.length <= n }.shuffled()) {
        if (puestas.size >= cuantas) break
        var ok = false; var t = 0
        while (!ok && t < 80) {
            t++
            val (dr, dc) = dirs.random(); val r = Random.nextInt(n); val c = Random.nextInt(n)
            val er = r + dr * (w.length - 1); val ec = c + dc * (w.length - 1)
            if (er in 0 until n && ec in 0 until n && w.indices.all { val x = g[r + dr * it][c + dc * it]; x == ' ' || x == w[it] }) {
                w.indices.forEach { g[r + dr * it][c + dc * it] = w[it] }
                puestas += w; ini[w] = r to c; ok = true
            }
        }
    }
    for (r in 0 until n) for (c in 0 until n) if (g[r][c] == ' ') g[r][c] = ('A'..'Z').random()
    return Puzzle(n, g, puestas, ini)
}

fun linea(a: Pair<Int, Int>, b: Pair<Int, Int>): List<Pair<Int, Int>> {
    val dr = b.first - a.first; val dc = b.second - a.second
    if (dr != 0 && dc != 0 && abs(dr) != abs(dc)) return listOf(a)
    val pasos = max(abs(dr), abs(dc))
    return (0..pasos).map { a.first + dr.sign * it to a.second + dc.sign * it }
}

val FONDO = Color(0xFF10141C); val TARJ = Color(0xFF1A2030); val ACENTO = Color(0xFF2DD4BF)
val PALETA = listOf(0xFFEF5350, 0xFFFFB74D, 0xFFFFF176, 0xFF81C784, 0xFF4FC3F7, 0xFF9575CD, 0xFFF06292, 0xFFA1887F, 0xFFAED581, 0xFF4DB6AC)
    .map { Color(it) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = ACENTO, background = FONDO, surface = TARJ)) {
                Surface(Modifier.fillMaxSize(), color = FONDO) { Juego() }
            }
        }
    }
}

@Composable
fun Juego() {
    val prefs = LocalContext.current.getSharedPreferences("sopa", Context.MODE_PRIVATE)
    var nivel by remember { mutableIntStateOf(1) }
    val tam = listOf(8, 10, 12)[nivel]
    var puzzle by remember { mutableStateOf(generar(10, 8)) }
    val found = remember { mutableStateMapOf<String, List<Pair<Int, Int>>>() }
    var sel by remember { mutableStateOf(listOf<Pair<Int, Int>>()) }
    var pista by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var resueltas by remember { mutableIntStateOf(prefs.getInt("resueltas", 0)) }

    fun nueva(n: Int = tam) { puzzle = generar(n, if (n == 8) 6 else if (n == 10) 8 else 10); found.clear(); sel = emptyList(); pista = null }
    val completa = found.size == puzzle.words.size
    LaunchedEffect(completa) { if (completa) { resueltas++; prefs.edit().putInt("resueltas", resueltas).apply() } }

    Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Sopa Infinita", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = ACENTO, modifier = Modifier.weight(1f))
            Text("Resueltas: $resueltas", color = Color.Gray, fontSize = 13.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Fácil", "Normal", "Difícil").forEachIndexed { i, t ->
                FilterChip(nivel == i, { nivel = i; nueva(listOf(8, 10, 12)[i]) }, { Text(t) })
            }
        }
        val n = puzzle.n
        Column(Modifier.fillMaxWidth().aspectRatio(1f).background(TARJ).pointerInput(puzzle) {
            var ini = 0 to 0
            fun celda(o: Offset): Pair<Int, Int> {
                val cs = size.width / n.toFloat()
                return (o.y / cs).toInt().coerceIn(0, n - 1) to (o.x / cs).toInt().coerceIn(0, n - 1)
            }
            detectDragGestures(
                onDragStart = { ini = celda(it); sel = listOf(ini) },
                onDrag = { ch, _ -> sel = linea(ini, celda(ch.position)) },
                onDragEnd = {
                    val s = sel.map { puzzle.grid[it.first][it.second] }.joinToString("")
                    val hit = puzzle.words.firstOrNull { it !in found && (it == s || it.reversed() == s) }
                    if (hit != null) { found[hit] = sel; pista = null }
                    sel = emptyList()
                }, onDragCancel = { sel = emptyList() })
        }) {
            for (r in 0 until n) Row(Modifier.weight(1f)) {
                for (c in 0 until n) {
                    val p = r to c
                    val fw = found.entries.firstOrNull { p in it.value }
                    val bg = when {
                        p in sel -> ACENTO.copy(alpha = 0.6f)
                        fw != null -> PALETA[puzzle.words.indexOf(fw.key) % PALETA.size].copy(alpha = 0.6f)
                        else -> Color.Transparent
                    }
                    Box(Modifier.weight(1f).fillMaxHeight().padding(1.dp).background(bg, RoundedCornerShape(6.dp))
                        .then(if (p == pista) Modifier.border(2.dp, ACENTO, RoundedCornerShape(6.dp)) else Modifier),
                        contentAlignment = Alignment.Center) {
                        Text("${puzzle.grid[r][c]}", fontSize = if (n > 10) 16.sp else 19.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        if (completa) Text("¡Sopa completada! 🎉", color = ACENTO, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        puzzle.words.chunked(3).forEach { fila ->
            Row(Modifier.fillMaxWidth()) {
                fila.forEach { w -> Text(w, Modifier.weight(1f), fontSize = 14.sp,
                    color = if (w in found) Color.Gray else Color.White,
                    textDecoration = if (w in found) TextDecoration.LineThrough else null) }
                repeat(3 - fila.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton({ pista = puzzle.words.firstOrNull { it !in found }?.let { puzzle.inicio[it] } }, Modifier.weight(1f)) { Text("Pista") }
            Button({ nueva() }, Modifier.weight(1f)) { Text("Nueva sopa") }
        }
        Text("Desliza el dedo sobre las letras. Las palabras pueden estar al derecho, al revés o en diagonal.", fontSize = 11.sp, color = Color.Gray)
    }
}
