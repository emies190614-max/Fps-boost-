package com.example.robloxfpsbooster

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Choreographer
import android.view.Window
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF00E5A0), background = Color(0xFF0E1116),
                surface = Color(0xFF181C24), onSurface = Color(0xFFE6E9EF))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Home(this) }
            }
        }
    }
}

@Composable
fun Home(act: ComponentActivity) {
    val pm = act.getSystemService(Context.POWER_SERVICE) as PowerManager
    val am = act.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val window: Window = act.window
    val ramGb = remember { ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.totalMem / 1e9 }
    val refresh = remember { act.display?.refreshRate ?: 60f }

    var keepOn by remember { mutableStateOf(false) }
    var sustained by remember { mutableStateOf(false) }
    var thermalAlert by remember { mutableStateOf(true) }
    var monitor by remember { mutableStateOf(true) }
    var fps by remember { mutableIntStateOf(0) }
    var saver by remember { mutableStateOf(pm.isPowerSaveMode) }
    var thermal by remember { mutableIntStateOf(pm.currentThermalStatus) }

    // Optimizaciones: solo afectan a la ventana de esta app (APIs públicas, sin permisos).
    LaunchedEffect(keepOn) {
        if (keepOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    LaunchedEffect(sustained) {
        if (pm.isSustainedPerformanceModeSupported) window.setSustainedPerformanceMode(sustained)
    }
    LaunchedEffect(Unit) { while (true) { saver = pm.isPowerSaveMode; thermal = pm.currentThermalStatus; delay(2000) } }

    // Monitor de FPS con Choreographer (mide los fotogramas de ESTA app).
    DisposableEffect(monitor) {
        var frames = 0; var start = 0L
        val cb = object : Choreographer.FrameCallback {
            override fun doFrame(t: Long) {
                if (start == 0L) start = t
                frames++
                if (t - start >= 500_000_000L) { fps = (frames * 1e9 / (t - start)).toInt(); frames = 0; start = t }
                if (monitor) Choreographer.getInstance().postFrameCallback(this)
            }
        }
        if (monitor) Choreographer.getInstance().postFrameCallback(cb)
        onDispose { Choreographer.getInstance().removeFrameCallback(cb) }
    }

    val tier = when { ramGb < 4 -> 0; ramGb < 8 -> 1; else -> 2 }
    val tips = listOf(
        listOf("Calidad gráfica: manual, nivel 1–3", "Desactiva sombras y efectos de luz", "Cierra apps en segundo plano antes de jugar"),
        listOf("Calidad gráfica: manual, nivel 4–6", "Reduce la distancia de renderizado", "Evita jugar cargando si el equipo se calienta"),
        listOf("Calidad gráfica: manual, nivel 7–10", "Usa la tasa de refresco máxima (${refresh.toInt()} Hz)", "Vigila la temperatura en sesiones largas"))[tier]
    val thermalText = listOf("Normal", "Ligero", "Moderado", "Severo", "Crítico", "Emergencia", "Apagado inminente").getOrElse(thermal) { "?" }

    Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Roblox FPS Booster", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Monitor de FPS", color = Color.Gray)
                Text(if (monitor) "$fps" else "—", fontSize = 64.sp, fontWeight = FontWeight.ExtraBold,
                    color = if (fps >= refresh * 0.9) MaterialTheme.colorScheme.primary else Color(0xFFFFB300))
                Text("Pantalla ${refresh.toInt()} Hz · ${"%.1f".format(ramGb)} GB RAM", color = Color.Gray, fontSize = 13.sp)
                Text("Mide los fotogramas de esta app; no puede leer los de Roblox.", color = Color.Gray, fontSize = 11.sp)
            }
        }

        Section("Optimizaciones") {
            Toggle("Mantener pantalla encendida", "Mientras esta app está abierta", keepOn) { keepOn = it }
            Toggle("Modo de rendimiento sostenido", if (pm.isSustainedPerformanceModeSupported) "Limita picos de calor" else "No compatible en este equipo", sustained) { sustained = it }
            Toggle("Aviso térmico", "Estado: $thermalText", thermalAlert) { thermalAlert = it }
            Toggle("Monitor de FPS", "Activar / desactivar medición", monitor) { monitor = it }
        }

        if (thermalAlert && thermal >= PowerManager.THERMAL_STATUS_MODERATE)
            Text("⚠ El dispositivo está caliente ($thermalText). Haz una pausa para evitar bajadas de FPS.", color = Color(0xFFFFB300))
        if (saver) Text("⚠ El ahorro de batería está activo y puede limitar el rendimiento.", color = Color(0xFFFFB300))

        Section("Recomendaciones para tu equipo") {
            tips.forEach { Text("• $it", Modifier.padding(vertical = 3.dp)) }
            Text("Se aplican manualmente en Roblox › Ajustes › Gráficos.", color = Color.Gray, fontSize = 12.sp)
        }

        Section("Ajustes del sistema") {
            Button({ act.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("Ahorro de batería") }
            OutlinedButton({ act.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("Pantalla y tasa de refresco") }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) =
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp); content()
        }
    }

@Composable
fun Toggle(title: String, sub: String, on: Boolean, change: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title); Text(sub, color = Color.Gray, fontSize = 12.sp) }
        Switch(on, change)
    }
